import React from 'react'

const About = () => {
  return (
  <div>this is About page</div>
  )
}

export default About